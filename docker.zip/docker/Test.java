public class Test {
	public static void main(String abb[]){
		System.out.println("Test Class ");
	}
}